import React from 'react';
export default function Navbar(){return <nav className='bg-indigo-800 text-white p-4'>Navbar</nav>}
