class Chunk: pass
class Hit: pass
class VectorIndex:
    def __init__(self,dim): self.dim=dim; self.chunks=[]
    def add(self,embs,chunks): self.chunks.extend(chunks)
    def search(self,q,k): return []
