import React from 'react';
export default function Programs(){return <section className='p-10'>Programs</section>}
