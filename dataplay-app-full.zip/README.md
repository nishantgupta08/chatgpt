# Dataplay — Example Next.js App (App Router, TypeScript, Tailwind)

This is a minimal scaffold pre-wired with App Router pages and a global header/navbar.
It includes sample Jaipur-focused course pages (SEO-friendly) while keeping the main navbar city-agnostic.

## Quick start
1. Install dependencies:
   ```bash
   npm ci
   # or
   # npm install
   ```

2. Run dev server:
   ```bash
   npm run dev
   ```

3. Open http://localhost:3000

## Notes
- Replace `utils/data.ts` with your CMS/database calls.
- Update `next.config.mjs` images.domains if you use remote logos.
- Update `app/sitemap.xml/route.ts` siteRoot to your production domain before submitting to Search Console.
