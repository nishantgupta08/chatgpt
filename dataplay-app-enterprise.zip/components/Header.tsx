import dynamic from 'next/dynamic';
const NavbarClient = dynamic(() => import('./Navbar.client'), { ssr: false });

export default function Header() {
  return <NavbarClient />;
}
