import { fetchAllCourses } from "@/utils/data";
import { NextResponse } from "next/server";

function urlEntry(loc: string, lastmod?: string) {
  return `
  <url>
    <loc>${loc}</loc>
    ${lastmod ? `<lastmod>${lastmod}</lastmod>` : ""}
    <changefreq>weekly</changefreq>
    <priority>0.7</priority>
  </url>`;
}

export async function GET() {
  const siteRoot = "https://www.yoursite.com";
  const courses = await fetchAllCourses();

  const urls = [
    { loc: `${siteRoot}/`, lastmod: undefined },
    { loc: `${siteRoot}/courses`, lastmod: undefined },
    { loc: `${siteRoot}/resources`, lastmod: undefined },
  ];

  for (const c of courses) {
    urls.push({
      loc: `${siteRoot}/${c.city}/courses/${c.category}/${c.slug}`,
      lastmod: c.updatedAt ?? undefined,
    });
  }

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
  <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    ${urls.map(u => urlEntry(u.loc, u.lastmod)).join("\n")}
  </urlset>`;

  return new NextResponse(xml, {
    headers: {
      "Content-Type": "application/xml",
      "Cache-Control": "public, max-age=0, s-maxage=3600",
    },
  });
}
