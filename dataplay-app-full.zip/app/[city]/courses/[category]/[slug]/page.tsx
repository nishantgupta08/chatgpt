import { fetchAllCourses, fetchCourseByCityCategorySlug } from "@/utils/data";
import { notFound } from "next/navigation";

type Props = { params: { city: string; category: string; slug: string } };
export const revalidate = 3600;

export async function generateStaticParams() {
  const all = await fetchAllCourses();
  return all.map(c => ({ city: c.city, category: c.category, slug: c.slug }));
}

export async function generateMetadata({ params }: Props) {
  const course = await fetchCourseByCityCategorySlug(params.city, params.category, params.slug);
  if (!course) return { title: "Course not found" };
  return {
    title: `${course.title} — ${params.city.charAt(0).toUpperCase() + params.city.slice(1)} | Dataplay`,
    description: course.description,
  };
}

export default async function CoursePage({ params }: Props) {
  const { city, category, slug } = params;
  const course = await fetchCourseByCityCategorySlug(city, category, slug);
  if (!course) return notFound();

  const siteRoot = "https://www.yoursite.com";
  const courseUrl = `${siteRoot}/${city}/courses/${category}/${slug}`;

  const courseLd = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: course.title,
    description: course.description,
    provider: { "@type": "Organization", name: "Dataplay", url: siteRoot },
    areaServed: { "@type": "Place", name: "Jaipur" },
  };

  const breadcrumbLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: `${siteRoot}/` },
      { "@type": "ListItem", position: 2, name: city, item: `${siteRoot}/${city}` },
      { "@type": "ListItem", position: 3, name: "Courses", item: `${siteRoot}/${city}/courses` },
      { "@type": "ListItem", position: 4, name: course.title, item: courseUrl },
    ],
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(courseLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbLd) }} />

      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold">{course.title}</h1>
        <p className="mt-2 text-gray-600">{course.description}</p>

        <dl className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <dt className="font-medium">Duration</dt>
            <dd className="text-sm text-gray-700">{course.duration ?? "N/A"}</dd>
          </div>
          <div>
            <dt className="font-medium">Price</dt>
            <dd className="text-sm text-gray-700">{course.price ? `₹${course.price}` : "Contact for pricing"}</dd>
          </div>
        </dl>

        <section className="mt-6">
          <h2 className="text-xl font-semibold">Instructors</h2>
          <ul className="mt-2">
            {course.instructors?.map(i => <li key={i.name} className="text-sm text-gray-700">{i.name}</li>)}
          </ul>
        </section>
      </div>
    </>
  );
}
