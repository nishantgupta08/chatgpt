export type Course = {
  city: string;
  category: string;
  slug: string;
  title: string;
  description: string;
  duration?: string;
  price?: number;
  instructors?: { name: string }[];
  updatedAt?: string;
};

export type City = { name: string; slug: string; region?: string };

export const CITIES: City[] = [
  { name: "Jaipur", slug: "jaipur" },
  { name: "Bangalore", slug: "bangalore" },
  { name: "Pune", slug: "pune" },
  { name: "Delhi", slug: "delhi" },
];

const COURSES: Course[] = [
  {
    city: "jaipur",
    category: "data-science",
    slug: "advanced-ml-bootcamp-jaipur",
    title: "Advanced ML Bootcamp — Jaipur",
    description: "Hands-on advanced machine learning bootcamp in Jaipur. 12 weeks, in-person + online support.",
    duration: "12 weeks",
    price: 45000,
    instructors: [{ name: "Dr. R. Sharma", profileUrl: "/instructors/r-sharma" }],
    updatedAt: "2025-09-01",
  },
  {
    city: "bangalore",
    category: "web-development",
    slug: "fullstack-web-dev-bangalore",
    title: "Fullstack Web Dev — Bangalore",
    description: "Practical fullstack web development with React & Node. 10 weeks.",
    duration: "10 weeks",
    price: 40000,
    instructors: [{ name: "S. Mehta" }],
    updatedAt: "2025-08-15",
  },
];

export async function fetchAllCourses(): Promise<Course[]> {
  return COURSES;
}

export async function fetchCoursesByCity(city: string): Promise<Course[]> {
  return COURSES.filter(c => c.city.toLowerCase() === city.toLowerCase());
}

export async function fetchCourseByCityCategorySlug(city: string, category: string, slug: string): Promise<Course | null> {
  const found = COURSES.find(c => c.city.toLowerCase() === city.toLowerCase() && c.category === category && c.slug === slug);
  return found ?? null;
}

export async function fetchAllCities(): Promise<City[]> {
  return CITIES;
}
