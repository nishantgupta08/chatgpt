class AppConfig:
    default_domains=["general","fintech","healthcare","legal","supply_chain"]
    fallback_decoder="google/flan-t5-base"
CONFIG=AppConfig()
