import { NextResponse } from 'next/server';

export async function GET() {
  const sitemapUrl = 'https://www.yoursite.com/sitemap.xml';
  const body = [
    'User-agent: *',
    'Allow: /',
    'Disallow: /api/private',
    'Sitemap: ' + sitemapUrl,
  ].join('\n');

  return new NextResponse(body, { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
}
