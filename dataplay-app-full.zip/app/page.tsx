import Link from "next/link";

export default function HomePage() {
  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold">Dataplay — Learn smarter</h1>
      <p className="mt-2 text-gray-600">Practical, mentor-led tech courses designed to get you job-ready.</p>

      <section className="mt-8">
        <h2 className="text-xl font-semibold">Our Bootcamps</h2>
        <p className="mt-2 text-gray-600">
          Learn Data Science, Web Development, and more. Our next batch starts soon.
          <br />
          <Link href="/courses" className="text-indigo-600 font-medium">Explore Courses →</Link>
        </p>

        <p className="mt-4 text-sm text-gray-500">
          Upcoming in-person workshops in Jaipur — <Link href="/jaipur/courses/data-science/advanced-ml-bootcamp-jaipur" className="text-indigo-600">see details</Link>.
        </p>
      </section>
    </div>
  );
}
