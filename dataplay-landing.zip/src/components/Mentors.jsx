import React from 'react';
export default function Mentors(){return <section className='p-10'>Mentors</section>}
