class Decoder:
    def __init__(self,name): self.name=name
    def generate(self,prompt,**kw): return f"[Mock answer for: {prompt[:50]}...]"
