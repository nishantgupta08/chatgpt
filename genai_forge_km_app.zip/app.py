import streamlit as st
st.title('GenAI-Forge KM Mock App')
query=st.text_input('Ask')
if st.button('Run'): st.write('Answer...')
