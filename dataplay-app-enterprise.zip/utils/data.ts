export type Course = {
  city: string;
  category: string;
  slug: string;
  title: string;
  description: string;
  duration?: string;
  price?: number;
  instructors?: { name: string }[];
  updatedAt?: string;
};

const COURSES: Course[] = [
  {
    city: "jaipur",
    category: "data-science",
    slug: "advanced-ml-bootcamp-jaipur",
    title: "Advanced ML Bootcamp — Jaipur",
    description: "Hands-on advanced machine learning bootcamp in Jaipur.",
    duration: "12 weeks",
    price: 45000,
    instructors: [{ name: "Dr. R. Sharma" }],
    updatedAt: "2025-09-01",
  },
];

export async function fetchAllCourses(): Promise<Course[]> {
  return COURSES;
}

export async function fetchCoursesByCity(city: string): Promise<Course[]> {
  return COURSES.filter(c => c.city === city.toLowerCase());
}

export async function fetchCourseByCityCategorySlug(city: string, category: string, slug: string): Promise<Course | null> {
  const found = COURSES.find(c => c.city === city.toLowerCase() && c.category === category && c.slug === slug);
  return found ?? null;
}
