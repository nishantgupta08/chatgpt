import React from 'react';
export default function Features(){return <section className='p-10 bg-gray-50'>Features</section>}
