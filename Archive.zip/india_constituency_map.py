"""
India Constituency Map using updated try.json
This script creates a map using the parliamentary constituency data from the updated try.json
"""

import folium
from folium import plugins
import json
import re

def extract_india_constituencies():
    """
    Extract India constituency data from the updated try.json file
    """
    try:
        with open('try.json', 'r') as f:
            data = json.load(f)
        
        constituencies_data = []
        states_data = {}
        
        for feature in data:
            if 'properties' in feature and 'geometry' in feature:
                pc_name = feature['properties'].get('PC_NAME', 'Unknown')
                state_name = feature['properties'].get('STATE_NAME', 'Unknown')
                pc_no = feature['properties'].get('PC_No', 0)
                st_code = feature['properties'].get('ST_CODE', 'Unknown')
                geometry_type = feature['geometry'].get('type', 'Unknown')
                coordinates = feature['geometry'].get('coordinates', [])
                
                print(f"Processing: {pc_name} in {state_name} ({st_code}) - {geometry_type}")
                
                # Convert coordinates to [lat, lng] format
                converted_coords = []
                
                try:
                    if geometry_type == 'MultiPolygon':
                        for polygon_group in coordinates:
                            for polygon in polygon_group:
                                for coord in polygon:
                                    if isinstance(coord, list) and len(coord) >= 2:
                                        converted_coords.append([float(coord[1]), float(coord[0])])  # [lat, lng]
                    elif geometry_type == 'Polygon':
                        for coord in coordinates:
                            if isinstance(coord, list) and len(coord) >= 2:
                                # Check if it's a nested list
                                if isinstance(coord[0], list):
                                    for sub_coord in coord:
                                        if isinstance(sub_coord, list) and len(sub_coord) >= 2:
                                            converted_coords.append([float(sub_coord[1]), float(sub_coord[0])])  # [lat, lng]
                                else:
                                    converted_coords.append([float(coord[1]), float(coord[0])])  # [lat, lng]
                    
                    if converted_coords:
                        constituency_info = {
                            'pc_name': pc_name,
                            'state_name': state_name,
                            'pc_no': pc_no,
                            'st_code': st_code,
                            'coordinates': converted_coords,
                            'geometry_type': geometry_type
                        }
                        constituencies_data.append(constituency_info)
                        
                        # Group by state
                        if state_name not in states_data:
                            states_data[state_name] = []
                        states_data[state_name].append(constituency_info)
                        
                        print(f"  Added {len(converted_coords)} coordinate points")
                    else:
                        print(f"  No valid coordinates found for {pc_name}")
                        
                except Exception as e:
                    print(f"  Error processing {pc_name}: {e}")
                    continue
        
        print(f"\nTotal constituencies processed: {len(constituencies_data)}")
        print(f"Total states: {len(states_data)}")
        return constituencies_data, states_data
        
    except Exception as e:
        print(f"Error extracting constituency data: {e}")
        return None, None

def create_india_constituency_map():
    """
    Create a map showing India with parliamentary constituencies
    """
    # Extract constituency data
    constituencies_data, states_data = extract_india_constituencies()
    
    if not constituencies_data:
        print("Could not extract constituency data, using fallback")
        return create_fallback_map()
    
    # Center coordinates for India
    india_center = [20.5937, 78.9629]
    
    # Create map with dark background
    m = folium.Map(
        location=india_center,
        zoom_start=5,
        tiles='CartoDB dark_matter',
        min_zoom=4,
        max_zoom=10
    )
    
    # Add each constituency as a separate polygon
    for constituency in constituencies_data:
        if constituency['coordinates']:
            folium.Polygon(
                locations=constituency['coordinates'],
                color='none',  # No border
                weight=0,      # No border weight
                fill=True,
                fillColor='lightblue',
                fillOpacity=0.8,
                popup=f'<b>{constituency["pc_name"]}</b><br>State: {constituency["state_name"]}<br>PC No: {constituency["pc_no"]}<br>ST Code: {constituency["st_code"]}'
            ).add_to(m)
    
    # Add major Indian cities
    major_cities = [
        ([28.6139, 77.2090], 'New Delhi', 'Capital of India'),
        ([19.0760, 72.8777], 'Mumbai', 'Financial Capital'),
        ([12.9716, 77.5946], 'Bangalore', 'IT Hub'),
        ([22.5726, 88.3639], 'Kolkata', 'Cultural Capital'),
        ([13.0827, 80.2707], 'Chennai', 'Gateway to South'),
        ([26.9124, 75.7873], 'Jaipur', 'Pink City'),
        ([23.0225, 72.5714], 'Ahmedabad', 'Gujarat'),
        ([21.1702, 72.8311], 'Surat', 'Gujarat'),
        ([30.7333, 76.7794], 'Chandigarh', 'Punjab & Haryana'),
        ([31.1048, 77.1734], 'Shimla', 'Himachal Pradesh')
    ]
    
    for coords, city, description in major_cities:
        folium.Marker(
            coords,
            popup=f'<b>{city}</b><br>{description}',
            tooltip=city,
            icon=folium.Icon(color='red', icon='star')
        ).add_to(m)
    
    # Add custom CSS to hide everything outside India
    constituency_css = """
    <style>
    .leaflet-container {
        background: #000 !important;
    }
    .leaflet-tile-pane {
        opacity: 0.1;
    }
    .leaflet-overlay-pane {
        z-index: 1000;
    }
    </style>
    """
    
    m.get_root().html.add_child(folium.Element(constituency_css))
    
    return m

def create_india_states_from_constituencies():
    """
    Create a map showing Indian states based on constituency data
    """
    # Extract constituency data
    constituencies_data, states_data = extract_india_constituencies()
    
    if not constituencies_data:
        print("Could not extract constituency data, using fallback")
        return create_fallback_map()
    
    # Center coordinates for India
    india_center = [20.5937, 78.9629]
    
    # Create map with dark background
    m = folium.Map(
        location=india_center,
        zoom_start=5,
        tiles='CartoDB dark_matter',
        min_zoom=4,
        max_zoom=10
    )
    
    # Add each state based on constituency data
    for state_name, state_constituencies in states_data.items():
        print(f"Processing state: {state_name} with {len(state_constituencies)} constituencies")
        
        # Combine all constituencies for this state
        all_coords = []
        for constituency in state_constituencies:
            if constituency['coordinates']:
                all_coords.extend(constituency['coordinates'])
        
        if all_coords:
            folium.Polygon(
                locations=all_coords,
                color='none',  # No border
                weight=0,      # No border weight
                fill=True,
                fillColor='lightblue',
                fillOpacity=0.8,
                popup=f'<b>{state_name}</b><br>Constituencies: {len(state_constituencies)}'
            ).add_to(m)
    
    # Add major Indian cities
    major_cities = [
        ([28.6139, 77.2090], 'New Delhi', 'Capital of India'),
        ([19.0760, 72.8777], 'Mumbai', 'Financial Capital'),
        ([12.9716, 77.5946], 'Bangalore', 'IT Hub'),
        ([22.5726, 88.3639], 'Kolkata', 'Cultural Capital'),
        ([13.0827, 80.2707], 'Chennai', 'Gateway to South'),
        ([26.9124, 75.7873], 'Jaipur', 'Pink City')
    ]
    
    for coords, city, description in major_cities:
        folium.Marker(
            coords,
            popup=f'<b>{city}</b><br>{description}',
            tooltip=city,
            icon=folium.Icon(color='red', icon='star')
        ).add_to(m)
    
    # Add custom CSS to hide everything outside India
    states_css = """
    <style>
    .leaflet-container {
        background: #000 !important;
    }
    .leaflet-tile-pane {
        opacity: 0.1;
    }
    .leaflet-overlay-pane {
        z-index: 1000;
    }
    </style>
    """
    
    m.get_root().html.add_child(folium.Element(states_css))
    
    return m

def create_fallback_map():
    """
    Create a fallback map if constituency data cannot be extracted
    """
    india_center = [20.5937, 78.9629]
    
    m = folium.Map(
        location=india_center,
        zoom_start=5,
        tiles='CartoDB dark_matter'
    )
    
    # Add India highlight - NO BORDER
    folium.Rectangle(
        bounds=[[6.0, 68.0], [37.0, 97.0]],
        color='none',  # No border
        weight=0,      # No border weight
        fill=True,
        fillColor='lightblue',
        fillOpacity=0.8,
        popup='India (Approximate)'
    ).add_to(m)
    
    return m

if __name__ == "__main__":
    print("Creating India constituency map using updated try.json...")
    
    # Create constituency map
    map1 = create_india_constituency_map()
    map1.save('india_constituency_map.html')
    print("India constituency map saved as 'india_constituency_map.html'")
    
    # Create states from constituencies map
    map2 = create_india_states_from_constituencies()
    map2.save('india_states_from_constituencies.html')
    print("India states from constituencies map saved as 'india_states_from_constituencies.html'")
    
    print("\nFeatures:")
    print("✅ Uses updated try.json with parliamentary constituency data")
    print("✅ Shows parliamentary constituencies")
    print("✅ Groups constituencies by state")
    print("✅ Only India is visible")
    print("✅ Everything else is hidden")
    print("✅ Constituency and state information")
    print("✅ Major Indian cities marked")
    print("✅ Clean, professional appearance")
    
    print("\nTo view the maps:")
    print("1. Open the HTML files in your web browser")
    print("2. Only India will be visible with constituency/state boundaries")
    print("3. Click on areas to see constituency/state information")
    print("4. Click on markers to see city information")
