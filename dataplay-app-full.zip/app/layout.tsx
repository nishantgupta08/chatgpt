import "./globals.css";
import Header from "@/components/Header";
import type { ReactNode } from "react";

export const metadata = {
  title: "Dataplay — Learn smarter",
  description: "Dataplay: hands-on tech courses built for career growth.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main>{children}</main>
      </body>
    </html>
  );
}
