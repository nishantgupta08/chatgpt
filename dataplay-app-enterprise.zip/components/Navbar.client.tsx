"use client";
import Link from 'next/link';
import Image from 'next/image';
import React, { useState } from 'react';

export default function NavbarClient() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
        <Link href="/" className="flex items-center" aria-label="Dataplay home">
          <Image src="/images/logo.svg" alt="Dataplay" width={140} height={40} priority />
        </Link>

        <nav className="hidden md:flex gap-6 items-center" aria-label="Primary">
          <Link href="/">Home</Link>
          <Link href="/courses">Courses</Link>
          <Link href="/resources">Resources</Link>
          <Link href="/about">About</Link>
          <Link href="/contact" className="ml-3 px-4 py-2 rounded bg-indigo-600 text-white">Get Started</Link>
        </nav>

        <button className="md:hidden p-2" aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(s => !s)}>
          <span className="sr-only">Toggle menu</span>
          <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" aria-hidden>
            {open ? <path d="M6 18L18 6M6 6l12 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /> : <path d="M4 6h16M4 12h16M4 18h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />}
          </svg>
        </button>
      </div>

      <div id="mobile-menu" className={`${open ? "block" : "hidden"} md:hidden border-t`}>
        <div className="px-2 pt-2 pb-3 space-y-1">
          <Link href="/" className="block px-3 py-2">Home</Link>
          <Link href="/courses" className="block px-3 py-2">Courses</Link>
          <Link href="/resources" className="block px-3 py-2">Resources</Link>
          <Link href="/about" className="block px-3 py-2">About</Link>
          <Link href="/contact" className="block px-3 py-2 mt-2 bg-indigo-600 text-white rounded text-center">Get Started</Link>
        </div>
      </div>
    </header>
  );
}
