def answer_with_fallback(decoder,query,hits,threshold): return 'Fallback','No answer',0.0
