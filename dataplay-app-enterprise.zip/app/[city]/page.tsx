import { fetchCoursesByCity } from '@/utils/data';
import Link from 'next/link';
import { notFound } from 'next/navigation';

type Props = { params: { city: string } };
export const revalidate = 3600;

export async function generateStaticParams() {
  return [{ city: 'jaipur' }];
}

export default async function CityPage({ params }: Props) {
  const { city } = params;
  const courses = await fetchCoursesByCity(city);
  if (!courses.length) return notFound();

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold capitalize">{city} — Tech Bootcamps</h1>
      <p className="mt-2 text-gray-600">Explore Dataplay’s instructor-led courses available in {city}.</p>
      <section className="mt-6 space-y-4">
        {courses.map(c => (
          <article key={c.slug} className="border rounded p-4">
            <Link href={`/${city}/courses/${c.category}/${c.slug}`} className="text-lg font-semibold text-indigo-600">{c.title}</Link>
            <p className="text-sm text-gray-600 mt-1">{c.description}</p>
          </article>
        ))}
      </section>
    </div>
  );
}
