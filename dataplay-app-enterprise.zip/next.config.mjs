/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: { appDir: true },
  images: {
    domains: ['images.unsplash.com', 'cdn.yoursite.com'],
    minimumCacheTTL: 60,
  },
};

export default nextConfig;
