class EncoderRegistry:
    def get(self,name):
        return self
    def encode(self,name,texts):
        import numpy as np; return np.random.rand(len(texts),768).astype('float32')
ENCODERS=EncoderRegistry()
