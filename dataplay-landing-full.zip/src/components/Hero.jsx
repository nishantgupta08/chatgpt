import React from 'react';
export default function Hero(){return <section className='p-10 bg-indigo-50'>Hero</section>}
