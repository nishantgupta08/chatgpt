PR-style patch for Dataplay SEO improvements
--------------------------------------------

Files included in the patch file `0001-add-robots-and-structured-data.patch`:
- public/robots.txt (new)
- lib/structured-data.ts (new)
- lib/seo.ts (modified: adds getDefaultJsonLd export to expose Organization JSON-LD)

How to apply:
1. Move this patch into the root of your repository (where `package.json` is).
2. Run:
   git apply 0001-add-robots-and-structured-data.patch
   # Inspect the changes with `git status` / `git diff`
   git add .
   git commit -m "chore(seo): add robots.txt, structured-data helpers, export default JSON-LD"
3. Deploy and verify.

Notes:
- Update `public/robots.txt` Sitemap URL to your real production sitemap (https://www.example.com -> your domain).
- The patch purposely does not add per-route `generateMetadata` changes; see the previous `seo_patch_dataplay.zip` for an example file you can copy into specific routes (e.g., app/courses/[slug]/page.tsx).
- If you want, I can produce a second patch that injects a `generateMetadata` implementation into specific routes in your repo. Provide which routes to target and I'll make it.

