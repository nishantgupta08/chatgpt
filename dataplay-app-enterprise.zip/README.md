# Dataplay — Enterprise Example

This project is a Next.js 13 App Router scaffold with enterprise SEO improvements.
