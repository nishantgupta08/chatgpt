import { fetchCoursesByCity } from "@/utils/data";
import Link from "next/link";

type Props = { params: { city: string } };
export const revalidate = 3600;

export default async function CityCoursesPage({ params }: Props) {
  const { city } = params;
  const courses = await fetchCoursesByCity(city);

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold capitalize">All {city} Courses</h1>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        {courses.map(c => (
          <article key={c.slug} className="border rounded p-4">
            <Link href={`/${city}/courses/${c.category}/${c.slug}`} className="text-lg font-semibold text-indigo-600">{c.title}</Link>
            <p className="text-sm text-gray-600 mt-1">{c.description}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
