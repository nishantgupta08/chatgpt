export type Meta = {
  title: string;
  description: string;
  canonical?: string;
  keywords?: string[];
  ogImage?: string;
  jsonLd?: object | object[];
  robots?: string;
};

export function buildTitle(title: string) {
  const brand = "Dataplay";
  return title.includes(brand) ? title : `${title} — ${brand}`;
}

export function defaultMeta() : Meta {
  return {
    title: "Dataplay — Learn smarter",
    description: "Dataplay: practical tech courses for job-ready skills.",
    canonical: "https://www.yoursite.com",
    robots: "index,follow",
  };
}
