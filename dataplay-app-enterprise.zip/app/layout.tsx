import './globals.css';
import Header from '@/components/Header';
import { defaultMeta } from '@/lib/seo';

export const metadata = {
  title: defaultMeta().title,
  description: defaultMeta().description,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header />
        <main>{children}</main>
      </body>
    </html>
  );
}
