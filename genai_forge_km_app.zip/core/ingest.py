def ingest_files(files,domain,encoder_name,indexes,chunk_size,overlap): return 0
